# 📸 examples/ — Few-shot 예시 사진 자리

이 폴더에 **두피 유형별 예시 사진**을 업로드하세요.

## 파일명 규칙 (metadata.json과 일치)

```
basp-o0-normal.jpeg      ← 정상 두피
basp-m1-mild.jpeg        ← M자 초기
basp-m2-mid.jpeg         ← M자 중기
basp-v1-vertex.jpeg      ← 정수리 초기
basp-v2-vertex-mid.jpeg  ← 정수리 중기
tongue-bai-thick.jpeg    ← 백태 두꺼움 (혀)
```

## 사진 출처 (라이선스 안전)

- 🌍 ISIC Archive (https://www.isic-archive.com) — 무료 의학 이미지
- 📚 Wikimedia Commons (Creative Commons)
- 🔬 PubMed Open Access 논문 도판
- 🎨 자체 AI 생성 (Nano Banana 2, DALL-E 등)

## 권장 사양

- 해상도: 1024×1024 이상
- 형식: JPEG
- 크기: 200KB 이하 (최적화)
- 비율: 3:4 또는 1:1

## ⚠️ 주의

- 실제 환자 사진 X (개인정보)
- 저작권 명확한 출처만 사용
- AI 생성 사진 권장 (저작권 자유)
